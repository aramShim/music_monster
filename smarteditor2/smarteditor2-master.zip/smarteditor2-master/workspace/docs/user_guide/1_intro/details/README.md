## 제공 기능 상세

SmartEditor2이 제공하는 각 기능을 툴바의 아이콘 순서로 알아본다. 번호 매기기 버튼, 글머리 기호 버튼, 내어쓰기 버튼, 들여쓰기 버튼은 툴바의 더보기 버튼(&gt;&gt;)을 클릭하면 나타난다.

![toolbar_more.png](/assets/toolbarmore.png)

그림 1 툴바 더보기 버튼
